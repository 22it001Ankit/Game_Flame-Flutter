import 'package:cosmic_havoc/firebase_options.dart';
import 'package:cosmic_havoc/my_game.dart';
import 'package:cosmic_havoc/overlays/game_over_overlay.dart';
import 'package:cosmic_havoc/overlays/login_overlay.dart';
import 'package:cosmic_havoc/overlays/signup_overlay.dart';
import 'package:cosmic_havoc/overlays/title_overlay.dart';
import 'package:cosmic_havoc/services/auth_service.dart';
import 'package:cosmic_havoc/services/google_auth_service.dart';
import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import 'package:firebase_core/firebase_core.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Firebase if configuration is available
  bool firebaseInitialized = false;
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    print('Firebase initialized successfully');
    firebaseInitialized = true;
  } catch (e) {
    print('Failed to initialize Firebase: $e');
    // Continue without Firebase
  }
  
  // Initialize auth service
  final AuthService authService = AuthService();
  await authService.initialize();

  // Check if there's an existing Firebase auth session
  if (firebaseInitialized) {
    try {
      final GoogleAuthService googleAuthService = GoogleAuthService();
      firebase_auth.User? firebaseUser = firebase_auth.FirebaseAuth.instance.currentUser;
      
      // If Firebase user exists but local auth doesn't, sync them
      if (firebaseUser != null && !authService.isAuthenticated.value) {
        print('Found Firebase user, syncing with local auth: ${firebaseUser.email}');
        await authService.loginWithGoogle(
          id: firebaseUser.uid,
          email: firebaseUser.email ?? '',
          username: firebaseUser.displayName ?? 'User',
        );
      }
    } catch (e) {
      print('Error checking Firebase auth state: $e');
    }
  }

  final MyGame game = MyGame();

  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
          brightness: Brightness.dark,
        ),
      ),
      home: GameWidget(
        game: game,
        overlayBuilderMap: {
          'GameOver': (context, MyGame game) => GameOverOverlay(game: game),
          'Title': (context, MyGame game) => TitleOverlay(game: game),
          'Login': (context, MyGame game) => LoginOverlay(game: game),
          'Signup': (context, MyGame game) => SignupOverlay(game: game),
        },
        initialActiveOverlays: const ['Title'],
      ),
    ),
  );
}
