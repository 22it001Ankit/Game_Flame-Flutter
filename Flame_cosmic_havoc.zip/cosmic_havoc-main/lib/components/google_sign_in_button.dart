import 'package:cosmic_havoc/services/google_auth_service.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

class GoogleSignInButton extends StatefulWidget {
  final Function() onSuccess;
  final Function(String)? onError;

  const GoogleSignInButton({
    super.key,
    required this.onSuccess,
    this.onError,
  });

  @override
  State<GoogleSignInButton> createState() => _GoogleSignInButtonState();
}

class _GoogleSignInButtonState extends State<GoogleSignInButton> {
  final GoogleAuthService _googleAuthService = GoogleAuthService();
  bool _isLoading = false;
  bool _isFirebaseInitialized = false;

  @override
  void initState() {
    super.initState();
    _checkFirebaseInitialization();
  }

  Future<void> _checkFirebaseInitialization() async {
    try {
      // Check if Firebase is initialized
      Firebase.app();
      setState(() {
        _isFirebaseInitialized = true;
      });
    } catch (e) {
      setState(() {
        _isFirebaseInitialized = false;
      });
      print('Firebase not initialized: $e');
    }
  }

  Future<void> _signInWithGoogle() async {
    if (!_isFirebaseInitialized) {
      if (widget.onError != null) {
        widget.onError!('Firebase is not properly configured. Please set up Firebase first.');
      }
      return;
    }

    try {
      setState(() {
        _isLoading = true;
      });

      final user = await _googleAuthService.signInWithGoogle();

      setState(() {
        _isLoading = false;
      });

      if (user != null) {
        widget.onSuccess();
      } else if (widget.onError != null) {
        widget.onError!('Google sign-in failed. Please try again later.');
      }
    } catch (e) {
      print('Error during Google sign-in: $e');
      setState(() {
        _isLoading = false;
      });
      
      // Format the error message for better readability
      String errorMessage = e.toString();
      if (errorMessage.contains('api-key-not-valid')) {
        errorMessage = 'Invalid API key. Please check your Firebase configuration.';
      } else if (errorMessage.contains('popup-closed-by-user')) {
        errorMessage = 'Sign-in cancelled. Please try again.';
      } else if (errorMessage.contains('network-request-failed')) {
        errorMessage = 'Network error. Please check your internet connection.';
      }
      
      if (widget.onError != null) {
        widget.onError!(errorMessage);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: _isLoading ? null : _signInWithGoogle,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        padding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 12,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(4),
        ),
      ),
      icon: _isLoading
          ? const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
              ),
            )
          : const Icon(
              Icons.g_mobiledata_rounded,
              color: Colors.red,
              size: 24,
            ),
      label: const Text(
        'Sign in with Google',
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
} 