import 'dart:convert';
import 'package:cosmic_havoc/models/user.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  // Singleton pattern for AuthService
  static final AuthService _instance = AuthService._internal();
  
  factory AuthService() => _instance;
  
  AuthService._internal();

  // Key for storing user data in SharedPreferences
  static const String _userKey = 'user_data';
  
  // Key for storing all registered users
  static const String _usersKey = 'registered_users';
  
  // Current logged in user
  User? _currentUser;
  
  // Getter for current user
  User? get currentUser => _currentUser;
  
  // Authentication state
  final ValueNotifier<bool> isAuthenticated = ValueNotifier<bool>(false);

  // Initialize the auth service
  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    final userData = prefs.getString(_userKey);
    
    if (userData != null) {
      _currentUser = User.fromJson(json.decode(userData));
      isAuthenticated.value = true;
    }
  }

  // Find a user by email
  Future<User?> findUserByEmail(String email) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // Get registered users
      final usersJson = prefs.getStringList(_usersKey) ?? [];
      final users = usersJson.map((e) => json.decode(e)).toList();
      
      // Find user with matching email
      final userJson = users.firstWhere(
        (u) => u['email'] == email,
        orElse: () => {},
      );
      
      if (userJson.isEmpty) {
        return null; // User not found
      }
      
      // Create user object (without password)
      final Map<String, dynamic> userData = {...userJson};
      userData.remove('password');
      
      return User.fromJson(userData);
    } catch (e) {
      print('Find user by email error: $e');
      return null;
    }
  }

  // Register a new user
  Future<User?> register({
    required String username,
    required String email,
    required String password,
  }) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // Get existing users
      final usersJson = prefs.getStringList(_usersKey) ?? [];
      final users = usersJson.map((e) => json.decode(e)).toList();
      
      // Check if email is already registered
      if (users.any((u) => u['email'] == email)) {
        return null; // Email already in use
      }
      
      // Create new user
      final newUser = User(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        username: username,
        email: email,
        highScore: 0,
      );
      
      // Add user credentials to list
      users.add({
        ...newUser.toJson(),
        'password': password, // In a real app, this should be hashed
      });
      
      // Save updated users list
      await prefs.setStringList(
        _usersKey,
        users.map((u) => json.encode(u)).toList(),
      );
      
      return newUser;
    } catch (e) {
      print('Registration error: $e');
      return null;
    }
  }

  // Register a user via Google auth
  Future<User?> registerWithGoogle({
    required String id,
    required String username,
    required String email,
  }) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // Get existing users
      final usersJson = prefs.getStringList(_usersKey) ?? [];
      final users = usersJson.map((e) => json.decode(e)).toList();
      
      // Check if email is already registered
      if (users.any((u) => u['email'] == email)) {
        // Update the existing user with Google ID if needed
        for (int i = 0; i < users.length; i++) {
          if (users[i]['email'] == email) {
            users[i]['id'] = id;
            users[i]['isGoogleUser'] = true;
            break;
          }
        }
        
        // Save updated users list
        await prefs.setStringList(
          _usersKey,
          users.map((u) => json.encode(u)).toList(),
        );
        
        // Return the existing user
        return findUserByEmail(email);
      }
      
      // Create new user with Google data
      final newUser = User(
        id: id,
        username: username,
        email: email,
        highScore: 0,
      );
      
      // Add user to list with Google flag
      users.add({
        ...newUser.toJson(),
        'isGoogleUser': true,
      });
      
      // Save updated users list
      await prefs.setStringList(
        _usersKey,
        users.map((u) => json.encode(u)).toList(),
      );
      
      // Set as current user
      _currentUser = newUser;
      isAuthenticated.value = true;
      
      // Save current user
      await prefs.setString(_userKey, json.encode(_currentUser!.toJson()));
      
      return newUser;
    } catch (e) {
      print('Google registration error: $e');
      return null;
    }
  }

  // Login with Google
  Future<bool> loginWithGoogle({
    required String id,
    required String username,
    required String email,
  }) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // Get registered users
      final usersJson = prefs.getStringList(_usersKey) ?? [];
      final users = usersJson.map((e) => json.decode(e)).toList();
      
      // Find user with matching email
      final userIndex = users.indexWhere((u) => u['email'] == email);
      
      if (userIndex == -1) {
        return false; // User not found
      }
      
      // Update Google ID if needed
      users[userIndex]['id'] = id;
      users[userIndex]['isGoogleUser'] = true;
      
      // Save updated users list
      await prefs.setStringList(
        _usersKey,
        users.map((u) => json.encode(u)).toList(),
      );
      
      // Create user object (without password)
      final Map<String, dynamic> userData = {...users[userIndex]};
      userData.remove('password');
      
      _currentUser = User.fromJson(userData);
      
      // Save current user
      await prefs.setString(_userKey, json.encode(_currentUser!.toJson()));
      
      isAuthenticated.value = true;
      return true;
    } catch (e) {
      print('Google login error: $e');
      return false;
    }
  }

  // Login a user
  Future<bool> login({
    required String email,
    required String password,
  }) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // Get registered users
      final usersJson = prefs.getStringList(_usersKey) ?? [];
      final users = usersJson.map((e) => json.decode(e)).toList();
      
      // Find user with matching email and password
      final userJson = users.firstWhere(
        (u) => u['email'] == email && u['password'] == password,
        orElse: () => {},
      );
      
      if (userJson.isEmpty) {
        return false; // Invalid credentials
      }
      
      // Create user object (without password)
      final Map<String, dynamic> userData = {...userJson};
      userData.remove('password');
      
      _currentUser = User.fromJson(userData);
      
      // Save current user
      await prefs.setString(_userKey, json.encode(_currentUser!.toJson()));
      
      isAuthenticated.value = true;
      return true;
    } catch (e) {
      print('Login error: $e');
      return false;
    }
  }

  // Logout the current user
  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_userKey);
    _currentUser = null;
    isAuthenticated.value = false;
  }

  // Update user's high score
  Future<void> updateHighScore(int score) async {
    if (_currentUser == null || score <= _currentUser!.highScore) {
      return;
    }
    
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // Update current user
      _currentUser = _currentUser!.copyWith(highScore: score);
      
      // Save updated user
      await prefs.setString(_userKey, json.encode(_currentUser!.toJson()));
      
      // Update in users list
      final usersJson = prefs.getStringList(_usersKey) ?? [];
      final users = usersJson.map((e) => json.decode(e)).toList();
      
      for (int i = 0; i < users.length; i++) {
        if (users[i]['id'] == _currentUser!.id) {
          users[i]['highScore'] = score;
          break;
        }
      }
      
      await prefs.setStringList(
        _usersKey,
        users.map((u) => json.encode(u)).toList(),
      );
    } catch (e) {
      print('Update high score error: $e');
    }
  }
} 