import 'package:cosmic_havoc/models/user.dart';
import 'package:cosmic_havoc/services/auth_service.dart';
import 'package:firebase_auth/firebase_auth.dart' as firebase;
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter/foundation.dart';

class GoogleAuthService {
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final firebase.FirebaseAuth _auth = firebase.FirebaseAuth.instance;
  final AuthService _authService = AuthService();

  // Singleton pattern
  static final GoogleAuthService _instance = GoogleAuthService._internal();
  factory GoogleAuthService() => _instance;
  GoogleAuthService._internal();

  // Stream to listen to authentication state changes
  Stream<firebase.User?> get authStateChanges => _auth.authStateChanges();

  // Get current Firebase user
  firebase.User? get currentUser => _auth.currentUser;

  // Sign in with Google
  Future<User?> signInWithGoogle() async {
    try {
      // For web
      if (kIsWeb) {
        // Configure Google Sign In
        firebase.GoogleAuthProvider googleProvider = firebase.GoogleAuthProvider();
        googleProvider.addScope('email');
        googleProvider.addScope('profile');
        
        // Use signInWithPopup for better user experience
        try {
          final firebase.UserCredential userCredential = 
              await _auth.signInWithPopup(googleProvider);
          return _handleSignInResult(userCredential.user);
        } catch (e) {
          // If popup is blocked, fallback to redirect
          if (e.toString().contains('popup-blocked')) {
            print('Popup was blocked, trying redirect flow');
            // Start redirect flow - Note: this will navigate away from the app
            await _auth.signInWithRedirect(googleProvider);
            // This code will not execute until the user returns to the app after authentication
            return null;
          } else {
            // Re-throw other errors
            rethrow;
          }
        }
      } 
      // For mobile
      else {
        final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
        if (googleUser == null) {
          return null; // User cancelled the sign-in flow
        }

        final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
        final firebase.AuthCredential credential = firebase.GoogleAuthProvider.credential(
          accessToken: googleAuth.accessToken,
          idToken: googleAuth.idToken,
        );

        final firebase.UserCredential userCredential = 
            await _auth.signInWithCredential(credential);
        return _handleSignInResult(userCredential.user);
      }
    } catch (e) {
      print('Error signing in with Google: $e');
      rethrow;
    }
  }

  // Handle successful sign-in
  Future<User?> _handleSignInResult(firebase.User? firebaseUser) async {
    if (firebaseUser == null) {
      return null;
    }

    // Check if the user exists in our local database
    final existingUser = await _getUserByEmail(firebaseUser.email!);
    
    if (existingUser != null) {
      // User exists, log them in
      await _authService.loginWithGoogle(
        email: firebaseUser.email!,
        id: firebaseUser.uid,
        username: firebaseUser.displayName ?? 'User',
      );
      return _authService.currentUser;
    } else {
      // Register new user
      final newUser = await _authService.registerWithGoogle(
        email: firebaseUser.email!,
        id: firebaseUser.uid,
        username: firebaseUser.displayName ?? 'User',
      );
      return newUser;
    }
  }

  // Check if a user exists with the given email
  Future<User?> _getUserByEmail(String email) async {
    return await _authService.findUserByEmail(email);
  }

  // Sign out
  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
    await _authService.logout();
  }
} 