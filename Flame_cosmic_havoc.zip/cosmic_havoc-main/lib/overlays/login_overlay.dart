import 'package:cosmic_havoc/components/google_sign_in_button.dart';
import 'package:cosmic_havoc/my_game.dart';
import 'package:cosmic_havoc/services/auth_service.dart';
import 'package:flutter/material.dart';

class LoginOverlay extends StatefulWidget {
  final MyGame game;

  const LoginOverlay({super.key, required this.game});

  @override
  State<LoginOverlay> createState() => _LoginOverlayState();
}

class _LoginOverlayState extends State<LoginOverlay> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final AuthService _authService = AuthService();
  
  bool _isLoading = false;
  String _errorMessage = '';

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    final success = await _authService.login(
      email: _emailController.text.trim(),
      password: _passwordController.text,
    );

    setState(() {
      _isLoading = false;
    });

    if (success) {
      // Handle successful login
      widget.game.overlays.remove('Login');
      widget.game.overlays.add('Title');
      widget.game.audioManager.playSound('click');
    } else {
      setState(() {
        _errorMessage = 'Invalid email or password';
      });
    }
  }

  void _navigateToSignup() {
    widget.game.audioManager.playSound('click');
    widget.game.overlays.remove('Login');
    widget.game.overlays.add('Signup');
  }
  
  void _handleGoogleSignInSuccess() {
    widget.game.audioManager.playSound('click');
    widget.game.overlays.remove('Login');
    widget.game.overlays.add('Title');
  }
  
  void _handleGoogleSignInError(String error) {
    setState(() {
      _errorMessage = 'Google sign-in failed: $error';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black.withOpacity(0.8),
      child: Center(
        child: Card(
          color: const Color(0xFF1A1A2E),
          elevation: 8,
          margin: const EdgeInsets.all(16),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Title
                  Text(
                    'COSMIC HAVOC',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.orange[400],
                    ),
                  ),
                  const SizedBox(height: 30),
                  
                  // Login form
                  Text(
                    'Login',
                    style: TextStyle(
                      fontSize: 24,
                      color: Colors.blue[200],
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 20),
                  
                  // Error message
                  if (_errorMessage.isNotEmpty)
                    Container(
                      padding: const EdgeInsets.all(8),
                      margin: const EdgeInsets.only(bottom: 15),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        _errorMessage,
                        style: const TextStyle(color: Colors.red),
                      ),
                    ),
                  
                  // Email field
                  TextField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    style: const TextStyle(color: Colors.white),
                    cursorColor: Colors.orange[400],
                    decoration: InputDecoration(
                      labelText: 'Email',
                      labelStyle: TextStyle(color: Colors.blue[100]),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.orange[400]!),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.blue[200]!),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // Password field
                  TextField(
                    controller: _passwordController,
                    obscureText: true,
                    style: const TextStyle(color: Colors.white),
                    cursorColor: Colors.orange[400],
                    decoration: InputDecoration(
                      labelText: 'Password',
                      labelStyle: TextStyle(color: Colors.blue[100]),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.orange[400]!),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.blue[200]!),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  
                  // Login button
                  ElevatedButton(
                    onPressed: _isLoading ? null : _login,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange[400],
                      padding: const EdgeInsets.symmetric(
                        horizontal: 40,
                        vertical: 12,
                      ),
                      textStyle: const TextStyle(fontSize: 18),
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : const Text('LOGIN'),
                  ),
                  const SizedBox(height: 24),
                  
                  // OR divider
                  Row(
                    children: [
                      Expanded(
                        child: Divider(
                          color: Colors.grey[700],
                          thickness: 1,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Text(
                          'OR',
                          style: TextStyle(
                            color: Colors.grey[500],
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Divider(
                          color: Colors.grey[700],
                          thickness: 1,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  
                  // Google Sign-in button
                  GoogleSignInButton(
                    onSuccess: _handleGoogleSignInSuccess,
                    onError: _handleGoogleSignInError,
                  ),
                  const SizedBox(height: 16),
                  
                  // Signup link
                  TextButton(
                    onPressed: _navigateToSignup,
                    child: const Text(
                      'Need an account? SIGN UP',
                      style: TextStyle(color: Colors.blue),
                    ),
                  ),
                  
                  // Back button
                  TextButton(
                    onPressed: () {
                      widget.game.audioManager.playSound('click');
                      widget.game.overlays.remove('Login');
                      widget.game.overlays.add('Title');
                    },
                    child: const Text(
                      'Back to Title',
                      style: TextStyle(color: Colors.white70),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
} 