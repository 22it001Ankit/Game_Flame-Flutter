import 'package:cosmic_havoc/my_game.dart';
import 'package:cosmic_havoc/services/auth_service.dart';
import 'package:flutter/material.dart';

class GameOverOverlay extends StatefulWidget {
  final MyGame game;

  const GameOverOverlay({super.key, required this.game});

  @override
  State<GameOverOverlay> createState() => _GameOverOverlayState();
}

class _GameOverOverlayState extends State<GameOverOverlay> {
  double _opacity = 0.0;
  final AuthService _authService = AuthService();
  bool _highScoreUpdated = false;

  @override
  void initState() {
    super.initState();

    // Update high score if user is authenticated
    _updateHighScore();

    Future.delayed(
      const Duration(milliseconds: 0),
      () {
        setState(() {
          _opacity = 1.0;
        });
      },
    );
  }

  Future<void> _updateHighScore() async {
    if (_authService.isAuthenticated.value && 
        _authService.currentUser != null && 
        !_highScoreUpdated) {
      final currentScore = widget.game.score;
      if (currentScore > _authService.currentUser!.highScore) {
        await _authService.updateHighScore(currentScore);
        _highScoreUpdated = true;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      onEnd: () {
        if (_opacity == 0.0) {
          widget.game.overlays.remove('GameOver');
        }
      },
      opacity: _opacity,
      duration: const Duration(milliseconds: 500),
      child: Container(
        color: Colors.black.withAlpha(150),
        alignment: Alignment.center,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'GAME OVER',
              style: TextStyle(
                color: Colors.white,
                fontSize: 48,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Score: ${widget.game.score}',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
              ),
            ),
            ValueListenableBuilder<bool>(
              valueListenable: _authService.isAuthenticated,
              builder: (context, isAuthenticated, _) {
                if (isAuthenticated && _authService.currentUser != null) {
                  final isNewHighScore = 
                      widget.game.score > _authService.currentUser!.highScore;
                  
                  return Column(
                    children: [
                      const SizedBox(height: 10),
                      if (isNewHighScore)
                        const Text(
                          'NEW HIGH SCORE!',
                          style: TextStyle(
                            color: Colors.amber,
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                          ),
                        )
                      else
                        Text(
                          'High Score: ${_authService.currentUser!.highScore}',
                          style: TextStyle(
                            color: Colors.amber[200],
                            fontSize: 20,
                          ),
                        ),
                    ],
                  );
                }
                return const SizedBox(height: 10);
              },
            ),
            const SizedBox(height: 30),
            TextButton(
              onPressed: () {
                widget.game.audioManager.playSound('click');
                widget.game.restartGame();
                setState(() {
                  _opacity = 0.0;
                });
              },
              style: TextButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                backgroundColor: Colors.blue,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(50),
                ),
              ),
              child: const Text(
                'PLAY AGAIN',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                ),
              ),
            ),
            const SizedBox(height: 15),
            TextButton(
              onPressed: () {
                widget.game.audioManager.playSound('click');
                widget.game.quitGame();
                setState(() {
                  _opacity = 0.0;
                });
              },
              style: TextButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                backgroundColor: Colors.blue,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(50),
                ),
              ),
              child: const Text(
                'QUIT GAME',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
