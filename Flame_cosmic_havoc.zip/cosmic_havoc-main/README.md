# Cosmic Havoc

A 2D space shooter game created with the Flame game engine in Flutter.

For a complete tutorial on how to create the game, check out this video on my YouTube channel [(Sweater Cat Studios)](https://www.youtube.com/@SweaterCatStudios): [Create a Game with Flutter & Flame - Free Course](https://youtu.be/aNWDGLgB6PQ?si=wUlOrqLVKgYuGTgY)

Full Game Dev and Graphic Design tutorials: https://sweatercatdesigns.com/
