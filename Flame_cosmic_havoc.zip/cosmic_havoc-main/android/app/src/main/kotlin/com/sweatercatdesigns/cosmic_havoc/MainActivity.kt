package com.sweatercatdesigns.cosmic_havoc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
